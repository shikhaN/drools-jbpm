package com.sample;

public class DueDateMessage {

    public static final int HELLO = 0;
    public static final int GOODBYE = 1;

    private String datemessage;
    private int duedate;
    /**
	 * @return the datemessage
	 */
	public String getDatemessage() {
		return datemessage;
	}
	/**
	 * @param datemessage the datemessage to set
	 */
	public void setDatemessage(String datemessage) {
		this.datemessage = datemessage;
	}
	/**
	 * @return the duedate
	 */
	public int getDuedate() {
		return duedate;
	}
	/**
	 * @param duedate the duedate to set
	 */
	public void setDuedate(int duedate) {
		this.duedate = duedate;
	}
	

    
}