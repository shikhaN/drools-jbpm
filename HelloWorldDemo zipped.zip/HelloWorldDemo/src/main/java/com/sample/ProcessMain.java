package com.sample;

import java.io.Serializable;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.jbpm.test.JBPMHelper;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.manager.RuntimeEnvironmentBuilder;
import org.kie.api.runtime.manager.RuntimeManager;
import org.kie.api.runtime.manager.RuntimeManagerFactory;

//import com.sample.DroolsTest.Message;

public class ProcessMain {

	public static void main(String[] args) {
		KieServices ks = KieServices.Factory.get();
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieBase kbase = kContainer.getKieBase("kbase");

		RuntimeManager manager = createRuntimeManager(kbase);
		RuntimeEngine engine = manager.getRuntimeEngine(null);
		KieSession ksession = engine.getKieSession();
		//Account account = new Account();
        //account.setMoney(0);
		//ksession.insert(account);
		  Message message = new Message();
          message.setMessage("rules message set from main class");
          message.setStatus(Message.HELLO);
          ksession.insert(message);
        //  ksession.fireAllRules();
		ksession.startProcess("com.sample.bpmn.hello");
		ksession.fireAllRules();

		manager.disposeRuntimeEngine(engine);
		System.exit(0);
	}

	private static RuntimeManager createRuntimeManager(KieBase kbase) {
		JBPMHelper.startH2Server();
		JBPMHelper.setupDataSource();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("org.jbpm.persistence.jpa");
		RuntimeEnvironmentBuilder builder = RuntimeEnvironmentBuilder.Factory.get()
			.newDefaultBuilder().entityManagerFactory(emf)
			.knowledgeBase(kbase);
		return RuntimeManagerFactory.Factory.get()
			.newSingletonRuntimeManager(builder.get(), "com.sample:example:1.0");
	}



	  public static class Message implements Serializable{

	        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
			public static final int HELLO = 0;
	        public static final int GOODBYE = 1;

	        private String message;

	        private int status;

	        public String getMessage() {
	            return this.message;
	        }

	        public void setMessage(String message) {
	            this.message = message;
	        }

	        public int getStatus() {
	            return this.status;
	        }

	        public void setStatus(int status) {
	            this.status = status;
	        }

	    }

}